﻿using System.ComponentModel.DataAnnotations;

namespace Identity.AuthServer.ViewModels.Account
{
    public class ExternalLoginConfirmationViewModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }
}
